import { useState } from 'react'

const email = 'ramanelite@flash.co'

const navItems = [
  ['home', 'Home'],
  ['about', 'About'],
  ['loadout', 'Loadout'],
  ['contact', 'Contact'],
]

const loadout = [
  { code: '01', title: 'BGMI Main', text: 'Ranked matches, clutch plays and squad energy.', tag: 'BATTLE ROYALE', tone: 'red' },
  { code: '02', title: 'Aim Lab', text: 'Training routines, sensitivity experiments and clean sprays.', tag: 'SKILL MODE', tone: 'violet' },
  { code: '03', title: 'Squad Comms', text: 'The place for drop plans, rotations and late-game calls.', tag: 'TEAM PLAY', tone: 'cyan' },
]

function App() {
  const [menuOpen, setMenuOpen] = useState(false)

  const jump = (id) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' })
    setMenuOpen(false)
  }

  return (
    <div className="site-shell">
      <div className="noise" aria-hidden="true" />
      <header className="topbar">
        <button className="brand" onClick={() => jump('home')} aria-label="Go to home">
          <span className="brand-mark">V</span>
          <span><strong>VOOID</strong><small>GAMES / BGMI</small></span>
        </button>
        <button className="menu-toggle" onClick={() => setMenuOpen(!menuOpen)} aria-label="Toggle menu">{menuOpen ? '×' : '☰'}</button>
        <nav className={menuOpen ? 'nav open' : 'nav'}>
          {navItems.map(([id, label]) => <button key={id} onClick={() => jump(id)}>{label}</button>)}
          <a className="nav-cta" href={`mailto:${email}`}>Contact me <span>↗</span></a>
        </nav>
      </header>

      <main>
        <section id="home" className="hero section-pad">
          <div className="hero-copy">
            <p className="eyebrow"><span className="pulse-dot" /> PLAYER PROFILE / ONLINE</p>
            <h1>PLAY LOUD.<br /><em>STAY VO OID.</em></h1>
            <p className="hero-text">Hey, I’m <strong>Vooid</strong> — a BGMI gamer from Uttar Pradesh. This is my corner of the map for matches, moments and squad-first energy.</p>
            <div className="hero-actions">
              <button className="primary-btn" onClick={() => jump('about')}>Enter the lobby <span>↗</span></button>
              <button className="text-btn" onClick={() => jump('contact')}>Get in touch <span>↓</span></button>
            </div>
            <div className="mini-stats" aria-label="Player details">
              <div><strong>18</strong><span>AGE</span></div>
              <div><strong>UP</strong><span>REGION</span></div>
              <div><strong>BGMI</strong><span>MAIN GAME</span></div>
            </div>
          </div>
          <div className="hero-art" aria-label="Vooid Games visual">
            <div className="scan-line" />
            <div className="crosshair"><span /><span /></div>
            <div className="art-ring ring-one" />
            <div className="art-ring ring-two" />
            <div className="art-core"><span className="core-v">V</span><span className="core-label">Vooid<br />Games</span></div>
            <div className="art-code code-top">DROP // 07:30<br />ZONE // ACTIVE</div>
            <div className="art-code code-bottom">N 27°<br />SQUAD READY</div>
            <span className="corner corner-tl" /><span className="corner corner-br" />
          </div>
        </section>

        <section id="about" className="about section-pad">
          <div className="section-label"><span>01</span> PLAYER CARD</div>
          <div className="about-grid">
            <div>
              <h2>Not here to<br /><span>blend in.</span></h2>
              <p className="section-text">Vooid Games is a personal gaming identity built around BGMI. No forced flex, no fake resume — just gameplay, good vibes and a place to share the grind.</p>
            </div>
            <div className="player-card">
              <div className="card-top"><span>PLAYER CARD</span><span>VGD / 001</span></div>
              <div className="avatar-orb">V</div>
              <div className="card-name">VOOID</div>
              <div className="card-role">BGMI PLAYER <span>•</span> UP, INDIA</div>
              <div className="card-rule" />
              <div className="card-bottom"><span>LVL 18</span><span>READY TO DROP</span></div>
            </div>
          </div>
        </section>

        <section id="loadout" className="loadout section-pad">
          <div className="section-heading"><div className="section-label"><span>02</span> CURRENT LOADOUT</div><p>What’s in the rotation.</p></div>
          <div className="loadout-grid">
            {loadout.map((item) => <article className={`loadout-card ${item.tone}`} key={item.code}>
              <div className="card-index">{item.code}</div>
              <div className="card-icon">{item.tone === 'red' ? '◈' : item.tone === 'violet' ? '⌁' : '＋'}</div>
              <div className="card-tag">{item.tag}</div>
              <h3>{item.title}</h3>
              <p>{item.text}</p>
              <span className="card-arrow">↗</span>
            </article>)}
          </div>
        </section>

        <section id="contact" className="contact section-pad">
          <div className="contact-panel">
            <div><p className="eyebrow">03 / OPEN CHANNEL</p><h2>DROP A<br /><em>MESSAGE.</em></h2></div>
            <div className="contact-copy"><p>For collabs, squad talk or just a friendly hello, send a message. The lobby is open.</p><a className="mail-link" href={`mailto:${email}`}>{email} <span>↗</span></a></div>
          </div>
        </section>
      </main>

      <footer className="footer"><span>© 2026 Vooid Games</span><span>BGMI / GAMING / UP</span><button onClick={() => jump('home')}>BACK TO TOP ↑</button></footer>
    </div>
  )
}

export default App
