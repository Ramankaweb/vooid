# Vooid Games — BGMI Portfolio

A custom gaming-focused landing page for **Vooid Games**, built around the BGMI identity of Vooid from Uttar Pradesh. The design uses a dark tactical HUD, red accent color, player card, loadout cards, and a direct contact CTA instead of copying the original iPhone-style portfolio layout.

## Personal details included

The page includes the name **Vooid**, brand **Vooid Games**, BGMI focus, Uttar Pradesh region, age 18, and the email address `ramanelite@flash.co`.

Location/map, skills, project showcase, work experience, old social links, old channel branding, and the original iPhone-style sections were removed from the active website.

## Run locally

```bash
npm install
npm run dev
```

## Production checks

```bash
npm run build
npm run lint
```

The app is a Vite + React site. Main content lives in `src/App.jsx` and the visual system lives in `src/index.css`.
