# Vooid Games visual verification

- Page title renders as `Vooid Games — BGMI Player`.
- Hero shows Vooid Games / BGMI branding, Vooid identity, age 18, UP region and BGMI main game.
- About section shows Player Card for Vooid and no work-experience content.
- Loadout section shows BGMI Main, Aim Lab and Squad Comms cards.
- Contact section exposes `ramanelite@flash.co` via a mailto link.
- The visual language is a dark tactical HUD with red, violet and cyan accents; it is not an iPhone-style layout.
- Browser viewport screenshots checked after scrolling through the hero, player card and loadout areas.
